#!/usr/bin/env python3
"""TWM ORION F21-P0: learn graph state transitions directly from transition histories.

Teacher uses ONE parametric smooth causal family for offline data only.
Scorer does NOT enumerate masks, use law IDs, or call teacher.
Compared arms have same architecture and same training/DEV budget.
"""
from __future__ import annotations
import argparse, copy, hashlib, json, math, random, time, zipfile
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

ROOT = Path(__file__).resolve().parents[1]
PFILE = ROOT / 'configs/PROTOCOL_FROZEN.json'
P = json.loads(PFILE.read_text())
PH = hashlib.sha256(PFILE.read_bytes()).hexdigest()
assert PH == (ROOT/'configs/PROTOCOL_SHA256.txt').read_text().strip()
torch.set_num_threads(1)
N = P['nodes']; K = P['observation_count']
EDGES = [(i,j) for i in range(N) for j in range(i+1,N)]
EI = np.array([e[0] for e in EDGES],dtype=np.int64)
EJ = np.array([e[1] for e in EDGES],dtype=np.int64)
E = len(EDGES)
INC = np.zeros((E,N),dtype=np.float32)
for k,(i,j) in enumerate(EDGES): INC[k,i]=-1.; INC[k,j]=1.
TRAIN_LAWS = ['+++','+--','-+-','--+']
DEV_LAWS = P['latent_laws']['dev_sign_patterns']
EXAM_LAWS = P['latent_laws']['exam_sign_patterns']
assert len(set(TRAIN_LAWS + DEV_LAWS + EXAM_LAWS))==8

def theta(code):
    assert len(code)==3 and set(code)<={'+','-'}
    return np.array([1.1,1.0,0.95],dtype=np.float32) * np.array([1 if c=='+' else -1 for c in code],dtype=np.float32)

def graph_mask(name):
    if name=='chain':pairs=[(i,i+1) for i in range(N-1)]
    elif name=='ring':pairs=[(i,i+1) for i in range(N-1)]+[(0,N-1)]
    elif name=='hub':pairs=[(0,i) for i in range(1,N)]
    elif name=='ladder':pairs=[(0,1),(1,2),(3,4),(4,5),(0,3),(1,4),(2,5)]
    elif name=='triadbridge':pairs=[(0,1),(1,2),(0,2),(3,4),(4,5),(3,5),(2,3)]
    else:raise ValueError(name)
    ss={tuple(sorted(p)) for p in pairs}
    return np.array([float(e in ss) for e in EDGES],dtype=np.float32)

def random_state(rng,adj):
    node=rng.uniform(.23,.77,size=(N,2)).astype(np.float32)
    rel=(rng.uniform(.25,.75,size=E)*adj).astype(np.float32)
    return node,rel

def random_action(rng,adj,solo=False):
    available=np.flatnonzero(adj)
    m=1 if solo else min(len(available),int(rng.integers(3,6)))
    ix=rng.choice(available,size=m,replace=False)
    a=np.zeros(E,dtype=np.float32)
    a[ix]=rng.uniform(.4,1.,size=m)
    return a

def teacher_step(node,rel,adj,act,law):
    """Offline-only synthetic environment: one generic smooth generator over theta.
    Not imported or called by neural forward. Clip is teacher's bounded-world rule.
    """
    th=theta(law)
    du=node[EI,0]-node[EJ,0]
    dp=node[EI,1]-node[EJ,1]
    rdev=rel-.5
    flow_r=.085*act*np.tanh(th[0]*du+th[1]*dp+th[2]*rdev)
    flow_p=.055*act*np.tanh(th[1]*du-th[0]*dp+th[2]*rdev)
    dr=np.einsum('en,e->n',INC,flow_r)
    dpn=np.einsum('en,e->n',INC,flow_p)
    drel=.04*act*np.tanh(th[2]*du+th[0]*dp+th[1]*rdev)
    next_node=np.clip(node+np.stack([dr,dpn],-1),0,1).astype(np.float32)
    next_rel=np.clip(rel+drel,0,1).astype(np.float32)*adj
    return next_node,next_rel

def support_token(node,rel,adj,action,after_node,after_rel,chosen):
    i,j=EDGES[chosen]
    return np.array([node[i,0],node[i,1],node[j,0],node[j,1],rel[chosen],action[chosen],
                     after_node[i,0]-node[i,0],after_node[j,0]-node[j,0],
                     after_node[i,1]-node[i,1],after_node[j,1]-node[j,1],
                     after_rel[chosen]-rel[chosen]],dtype=np.float32)

def make_context(rng,adj,laws):
    """Create same interventions for each law; only observed after-state changes."""
    baseline=[]
    for k in range(K):
        n,r=random_state(rng,adj)
        # Broader intervention contrasts help discriminate coefficient signs.
        if k%3==0:n[:,0]=np.linspace(.18,.82,N,dtype=np.float32)
        if k%3==1:n[:,1]=np.linspace(.82,.18,N,dtype=np.float32)
        a=random_action(rng,adj,solo=True)
        baseline.append((n,r,a,int(np.flatnonzero(a)[0])))
    out={}
    for law in laws:
        vals=[]
        for n,r,a,ix in baseline:
            nn,rr=teacher_step(n,r,adj,a,law)
            vals.append(support_token(n,r,adj,a,nn,rr,ix))
        out[law]=np.stack(vals)
    return out

def make_dataset(seed,split):
    rng=np.random.default_rng({'train':11000000,'dev':22000000,'exam':33000000}[split]+seed*3137)
    laws={'train':TRAIN_LAWS,'dev':DEV_LAWS,'exam':EXAM_LAWS}[split]
    graphs=P['graph_train' if split=='train' else 'graph_dev' if split=='dev' else 'graph_exam']
    count=P['world_pairs_per_seed'][split]
    obj={'node':[],'rel':[],'adj':[],'act':[],'support':[],'target_node':[],'target_rel':[],
         'law':[],'pair_id':[],'graph':[]}
    for j in range(count):
        graph=graphs[j%len(graphs)];adj=graph_mask(graph)
        n,r=random_state(rng,adj);a=random_action(rng,adj)
        la,lb=rng.choice(laws,size=2,replace=False)
        context=make_context(rng,adj,[la,lb])
        for law in (la,lb):
            nn,rr=teacher_step(n,r,adj,a,law)
            for name,val in [('node',n),('rel',r),('adj',adj),('act',a),('support',context[law]),
                             ('target_node',nn),('target_rel',rr),('law',str(law)),('pair_id',j),('graph',graph)]:
                obj[name].append(val)
    tensor_keys=('node','rel','adj','act','support','target_node','target_rel')
    out={name:torch.from_numpy(np.stack(obj[name])).float() for name in tensor_keys}
    out.update({key:obj[key] for key in ('law','pair_id','graph')})
    assert len(out['law'])==count*2
    return out

def subset(data,ix):
    return {key:val[ix] for key,val in data.items() if isinstance(val,torch.Tensor)}

class DirectWorldModel(nn.Module):
    """Transition memory + graph edge network. No mask ranking or teacher features."""
    def __init__(self):
        super().__init__()
        self.memory=nn.Sequential(nn.Linear(11,64),nn.SiLU(),nn.Linear(64,32),nn.Tanh())
        self.flow=nn.Sequential(nn.Linear(39,96),nn.SiLU(),nn.Linear(96,96),nn.SiLU(),nn.Linear(96,3))
        self.register_buffer('inc',torch.from_numpy(INC))
        self.register_buffer('ei',torch.from_numpy(EI))
        self.register_buffer('ej',torch.from_numpy(EJ))
    def forward(self,node,rel,adj,act,support,use_context=True):
        B=node.shape[0]
        if not use_context:support=torch.zeros_like(support)
        z=self.memory(support).mean(1)
        edge_input=torch.cat([node[:,self.ei],node[:,self.ej],rel[...,None],
                              act[...,None],adj[...,None],z[:,None,:].expand(B,E,32)],-1)
        # Three learned continuous edge effects; graph incidence only routes node updates.
        flows=self.flow(edge_input)*act[...,None]*adj[...,None]
        dnode=torch.einsum('en,bec->bnc',self.inc,flows[...,:2])
        drel=flows[...,2]
        return node+dnode,rel+drel,dnode,drel

def loss_fn(pred,datum):
    node,rel=pred[:2]
    # Targets have small deltas. Scale dimensions equally before optimizing.
    errn=((node-datum['target_node'])**2).mean()/(.04**2)
    errr=((((rel-datum['target_rel'])*datum['adj'])**2).sum()/datum['adj'].sum().clamp_min(1))/(.025**2)
    return errn+errr

@torch.no_grad()
def evaluate(model,data,context):
    model.eval();pr=model(data['node'],data['rel'],data['adj'],data['act'],data['support'],use_context=context)
    errn=(pr[0]-data['target_node']).abs().mean().item()
    errr=((pr[1]-data['target_rel']).abs()*data['adj']).sum().item()/data['adj'].sum().item()
    xerr=(pr[0]-data['target_node']).abs().amax((1,2))
    rerr=((pr[1]-data['target_rel']).abs()*data['adj']).amax(1)
    exact=(torch.maximum(xerr,rerr)<=P['rollout']['exact_tolerance']).sum().item()
    near=(torch.maximum(xerr,rerr)<=P['rollout']['near_tolerance']).sum().item()
    invalid=((pr[0]<0).any((1,2))|(pr[0]>1).any((1,2))|
             (((pr[1]<-1e-6)|(pr[1]>1+1e-6))&(data['adj']>0)).any(1)).sum().item()
    return {'loss':float(loss_fn(pr,data)),'node_mae':errn,'relation_mae':errr,'exact_0.02':int(exact),
            'near_0.05':int(near),'invalid':int(invalid),'n':len(data['node'])}

def load(seed,arm):
    ck=torch.load(ROOT/'checkpoints'/f'{arm}_{seed}.pt',map_location='cpu',weights_only=True)
    assert ck['protocol_sha256']==PH and ck['seed']==seed and ck['arm']==arm
    net=DirectWorldModel().eval();net.load_state_dict(ck['model']);return net

def train(seed):
    assert not (ROOT/'results'/'EXAM_UNLOCKED').exists(),'Exam opened; no further selection'
    t=time.time();tr=make_dataset(seed,'train');dv=make_dataset(seed,'dev')
    print('DATA READY',seed,len(tr['node']),len(dv['node']),'seconds',round(time.time()-t,1),flush=True)
    result={'seed':seed,'protocol_sha256':PH,'arms':{},'pair_count_train':P['world_pairs_per_seed']['train']}
    for arm in P['arms']:
        torch.manual_seed(seed+102);net=DirectWorldModel();opt=torch.optim.AdamW(net.parameters(),
            lr=P['optimizer']['lr'],weight_decay=P['optimizer']['weight_decay'])
        rng=np.random.default_rng(seed+999);best=(float('inf'),float('inf'));selected=None;stepbest=0;history=[]
        for step in range(1,P['optimizer']['steps']+1):
            pair_ix=rng.integers(0,P['world_pairs_per_seed']['train'],size=P['optimizer']['batch_pairs'])
            ix=torch.tensor(np.stack([2*pair_ix,2*pair_ix+1],-1).ravel())
            batch=subset(tr,ix)
            net.train();pred=net(batch['node'],batch['rel'],batch['adj'],batch['act'],batch['support'],arm=='observed_context')
            loss=loss_fn(pred,batch)
            opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),P['optimizer']['grad_clip']);opt.step()
            if step in P['optimizer']['eval_steps']:
                met=evaluate(net,dv,arm=='observed_context');history.append({'step':step,**met})
                key=(met['loss'],met['node_mae']+met['relation_mae'])
                if key<best:best=key;selected=copy.deepcopy(net.state_dict());stepbest=step
        torch.save({'protocol_sha256':PH,'seed':seed,'arm':arm,'step':stepbest,'model':selected},
                   ROOT/'checkpoints'/f'{arm}_{seed}.pt')
        result['arms'][arm]={'selected_step':stepbest,'selected_dev':next(z for z in history if z['step']==stepbest),
                             'dev_history':history}
        print('TRAIN',seed,arm,'DEV',result['arms'][arm]['selected_dev'],'seconds',round(time.time()-t,1),flush=True)
    (ROOT/'results'/f'train_{seed}.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')

@torch.no_grad()
def exam(seed):
    for s in P['seeds']:
        for a in P['arms']:assert (ROOT/'checkpoints'/f'{a}_{s}.pt').exists()
    (ROOT/'results'/'EXAM_UNLOCKED').write_text('Both seeds and arms selected on DEV before EXAM.\n')
    data=make_dataset(seed,'exam');A=load(seed,'no_context');B=load(seed,'observed_context')
    out={'seed':seed,'protocol_sha256':PH,'n':len(data['node']),
         'metrics':{'no_context':evaluate(A,data,False),'observed_context':evaluate(B,data,True)},'pairs':[]}
    p=B(data['node'],data['rel'],data['adj'],data['act'],data['support'],True)
    swapped=data['support'].reshape(-1,2,K,11).flip(1).reshape(-1,K,11)
    ps=B(data['node'],data['rel'],data['adj'],data['act'],swapped,True)
    no=B(data['node'],data['rel'],data['adj'],data['act'],torch.zeros_like(data['support']),True)
    err=lambda pred: (pred[0]-data['target_node']).abs().mean((1,2)) + (((pred[1]-data['target_rel']).abs()*data['adj']).sum(1)/data['adj'].sum(1))
    e1=err(p);e2=err(ps);e3=err(no)
    dist=torch.cat([(p[0]-ps[0]).abs().amax((1,2))[:,None],(p[1]-ps[1]).abs().amax(1)[:,None]],1).amax(1)
    for i in range(len(e1)//2):
        j=2*i
        out['pairs'].append({'pair':i,'laws':data['law'][j:j+2],'graph':data['graph'][j],
                             'true_error':[float(e1[j]),float(e1[j+1])],
                             'swapped_error':[float(e2[j]),float(e2[j+1])],
                             'zero_error':[float(e3[j]),float(e3[j+1])],
                             'max_prediction_change':[float(dist[j]),float(dist[j+1])]})
    out['support_ablation']={'true_mean_error':float(e1.mean()),'swapped_mean_error':float(e2.mean()),
        'zero_mean_error':float(e3.mean()),'changed_at_1e-3':int((dist>0.001).sum()),
        'changed_at_1e-2':int((dist>0.01).sum()),'n':len(dist),
        'swap_improves':int((e2<e1-1e-6).sum()),'swap_hurts':int((e2>e1+1e-6).sum())}
    (ROOT/'results'/f'exam_{seed}.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print('EXAM',seed,out['metrics'],out['support_ablation'],flush=True)

@torch.no_grad()
def rollout(seed):
    A=load(seed,'no_context');B=load(seed,'observed_context');models={'no_context':A,'observed_context':B}
    records=[]
    for group,count in P['rollout']['episodes_per_seed'].items():
        for j in range(count):
            rng=np.random.default_rng(44000000+seed*11393+j*1199+{'ood':0,'familiar':1000000,'scrambled':2000000}[group])
            graph=(P['graph_train'] if group=='familiar' else P['graph_exam'])[j%len(P['graph_train'] if group=='familiar' else P['graph_exam'])]
            law=(TRAIN_LAWS if group=='familiar' else EXAM_LAWS)[j%len(TRAIN_LAWS if group=='familiar' else EXAM_LAWS)]
            adj=graph_mask(graph);st,rel=random_state(rng,adj)
            obs=make_context(rng,adj,[law])[law]
            goldst=st.copy();goldrel=rel.copy()
            states={k:(st.copy(),rel.copy()) for k in models}
            cases={k:{'prefix_0.02':90,'prefix_0.05':90,'stop_at':None,'steps':[]} for k in models}
            actions=[random_action(rng,adj) for _ in range(90)]
            if group=='scrambled':actions=[actions[(t*37+11)%90] for t in range(90)]
            for t,action in enumerate(actions):
                goldst,goldrel=teacher_step(goldst,goldrel,adj,action,law)
                for name,model in models.items():
                    log=cases[name]
                    if log['stop_at'] is not None:continue
                    sn,sr=states[name]
                    ton=lambda x:torch.from_numpy(np.asarray(x,dtype=np.float32))[None]
                    pp=model(ton(sn),ton(sr),ton(adj),ton(action),ton(obs),name=='observed_context')
                    pn=pp[0][0].numpy();pr=pp[1][0].numpy()
                    invalid=bool((pn<-1e-6).any() or (pn>1+1e-6).any() or
                                 (pr[adj>0]<-1e-6).any() or (pr[adj>0]>1+1e-6).any() or
                                 not np.all(np.isfinite(pn)) or not np.all(np.isfinite(pr)))
                    err=float(max(np.max(np.abs(pn-goldst)),np.max(np.abs((pr-goldrel)*adj))))
                    if err>.02 and log['prefix_0.02']==90:log['prefix_0.02']=t
                    if err>.05 and log['prefix_0.05']==90:log['prefix_0.05']=t
                    log['steps'].append({'step':t+1,'max_abs_error':err,'invalid':invalid})
                    if invalid:log['stop_at']=t+1
                    else:states[name]=(pn,pr)
            for name in models:
                r=cases[name]
                for h in (1,4,16,90):
                    r[f'H{h}_0.02']=int(r['prefix_0.02']>=h and (r['stop_at'] is None or r['stop_at']>h))
                    r[f'H{h}_0.05']=int(r['prefix_0.05']>=h and (r['stop_at'] is None or r['stop_at']>h))
            records.append({'seed':seed,'group':group,'graph':graph,'law_diagnostic':law,'models':cases})
        print('ROLLOUT',seed,group,count,flush=True)
    (ROOT/'results'/f'rollout_{seed}.json').write_text(json.dumps({'seed':seed,'records':records},indent=2,ensure_ascii=False)+'\n')


def report():
    reports=[json.loads((ROOT/'results'/f'exam_{s}.json').read_text()) for s in P['seeds']]
    rollout_recs=[r for seed in P['seeds'] for r in json.loads((ROOT/'results'/f'rollout_{seed}.json').read_text())['records']]
    res={'project':'TWM ORION','stage':'F21-P0','protocol_sha256':PH,'exam':{},'rollout':{},'support_ablation':{},'status':'UNDECIDED'}
    for arm in P['arms']:
        exam_summary={}
        for k in ('node_mae','relation_mae','loss'):
            exam_summary[k]=sum(e['metrics'][arm][k]*e['n'] for e in reports)/sum(e['n'] for e in reports)
        for k in ('exact_0.02','near_0.05','invalid','n'):
            exam_summary[k]=sum(e['metrics'][arm][k] for e in reports)
        res['exam'][arm]=exam_summary
        res['rollout'][arm]={}
        for group in P['rollout']['episodes_per_seed']:
            rs=[r['models'][arm] for r in rollout_recs if r['group']==group]
            res['rollout'][arm][group]={'n':len(rs),'halts':sum(x['stop_at'] is not None for x in rs),
                **{f'H{h}_0.02':sum(x[f'H{h}_0.02'] for x in rs) for h in [1,4,16,90]},
                **{f'H{h}_0.05':sum(x[f'H{h}_0.05'] for x in rs) for h in [1,4,16,90]}}
    for k in reports[0]['support_ablation']:
        res['support_ablation'][k]=sum(x['support_ablation'][k] for x in reports)
    for k in ('true_mean_error','swapped_mean_error','zero_mean_error'):
        res['support_ablation'][k]/=len(reports)
    ctrl,ctx=res['exam']['no_context'],res['exam']['observed_context']
    gate={'exam_node_mae_decrease':ctx['node_mae']<ctrl['node_mae'],
          'exam_rel_mae_decrease':ctx['relation_mae']<ctrl['relation_mae'],
          'swap_degrades':res['support_ablation']['swapped_mean_error']>res['support_ablation']['true_mean_error'],
          'ood_H16_0.02_gain':res['rollout']['observed_context']['ood']['H16_0.02']>res['rollout']['no_context']['ood']['H16_0.02'],
          'familiar_H4_0.02_no_regression':res['rollout']['observed_context']['familiar']['H4_0.02']>=res['rollout']['no_context']['familiar']['H4_0.02']}
    res['gate']=gate;res['status']='PASS' if all(gate.values()) else 'REJECT_NO_SYSTEM_GAIN'
    (ROOT/'results'/'SUMMARY.json').write_text(json.dumps(res,indent=2,ensure_ascii=False)+'\n')
    print('REPORT',res['status'],json.dumps(res['gate']),flush=True)


def tests():
    assert len(EDGES)==15
    rng=np.random.default_rng(16)
    for gr in P['graph_train']+P['graph_exam']:
        adj=graph_mask(gr);n,r=random_state(rng,adj);act=random_action(rng,adj)
        for law in TRAIN_LAWS+DEV_LAWS+EXAM_LAWS:
            nn,rr=teacher_step(n,r,adj,act,law)
            assert nn.shape==(N,2) and rr.shape==(E,)
            assert np.all(nn>=0) and np.all(nn<=1) and np.all(rr[adj>0]>=0)
    d=make_dataset(1321,'train');assert len(d['node'])==960
    # paired queries are IDENTICAL, contexts reflect different output laws
    for k in ('node','rel','adj','act'):
        assert torch.equal(d[k][0::2],d[k][1::2]),k
    assert not torch.equal(d['support'][0],d['support'][1])
    net=DirectWorldModel().eval();batch=subset(d,torch.tensor([0,1]))
    with torch.no_grad():
        y=net(batch['node'],batch['rel'],batch['adj'],batch['act'],batch['support'],True)
        yy=net(batch['node'],batch['rel'],batch['adj'],batch['act'],batch['support'][:,torch.randperm(K)],True)
        assert torch.allclose(y[0],yy[0],atol=1e-6) and torch.allclose(y[1],yy[1],atol=1e-6)
        z=net(batch['node'],batch['rel'],batch['adj'],batch['act'],batch['support'],False)
        # zero-context paired inputs are identical by construction
        assert torch.allclose(z[0][0],z[0][1])
    assert not set(DirectWorldModel.forward.__code__.co_names)&{'teacher_step','theta','offline_label','candidate_neural'}
    print('TESTS PASSED: counterfactual pairs, structural state, causal memory permutation invariance, no teacher forward',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('cmd',choices=['tests','train','exam','rollout','report']);ap.add_argument('--seed',type=int,default=1321)
    a=ap.parse_args()
    if a.cmd=='tests':tests()
    elif a.cmd=='train':train(a.seed)
    elif a.cmd=='exam':exam(a.seed)
    elif a.cmd=='rollout':rollout(a.seed)
    elif a.cmd=='report':report()
