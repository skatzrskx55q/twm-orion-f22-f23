#!/usr/bin/env python3
"""TWM ORION F21-P1: support leave-one-out system identification for direct world dynamics.
P0 archived unchanged; P1 training is a DISTINCT preregistered experiment on new world seeds.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
import orion_f21 as p0
ROOT=Path(__file__).resolve().parents[1]
PROTO=ROOT/'configs/PROTOCOL_P1_FROZEN.json'
P=json.loads(PROTO.read_text());PH=hashlib.sha256(PROTO.read_bytes()).hexdigest()
assert PH==(ROOT/'configs/PROTOCOL_P1_SHA256.txt').read_text().strip()
assert P['upstream_protocol_sha256']==p0.PH
torch.set_num_threads(1)
SCALE=torch.tensor([.05,.05,.035,.035,.025],dtype=torch.float32)

class DirectWorldModelP1(p0.DirectWorldModel):
    """Predict next node/relation states, with cause memory trained to predict withheld observations."""
    def latent(self,support,use_context):
        if not use_context:support=torch.zeros_like(support)
        # Fixed observational unit scaling; does NOT decode a law or select an effect.
        x=torch.cat((support[...,:6],support[...,6:]/SCALE.to(support.device)),dim=-1)
        return self.memory(x).mean(1)
    def forward(self,node,rel,adj,act,support,use_context=True):
        B=node.shape[0]
        z=self.latent(support,use_context)
        edge_input=torch.cat([node[:,self.ei],node[:,self.ej],rel[...,None],
                              act[...,None],adj[...,None],z[:,None,:].expand(B,p0.E,32)],dim=-1)
        flows=self.flow(edge_input)*act[...,None]*adj[...,None]
        dnode=torch.einsum('en,bec->bnc',self.inc,flows[...,:2]);drel=flows[...,2]
        return node+dnode,rel+drel,dnode,drel
    def withheld(self,support,hold_ix,use_context):
        keep=[i for i in range(p0.K) if i!=hold_ix]
        z=self.latent(support[:,keep],use_context)
        obs=support[:,hold_ix]
        # Single observed edge acted on. Last five fields are observed before->after changes.
        inp=torch.cat([obs[:,:6],torch.ones(len(obs),1,device=obs.device),z],dim=-1)
        flow=self.flow(inp)*obs[:,5:6]
        # Generic graph orientation: recipient node gains the edge flow.
        target=torch.stack([obs[:,7],obs[:,9],obs[:,10]],dim=-1)
        scales=torch.tensor([.04,.03,.025],device=obs.device)
        return (((flow-target)/scales)**2).mean()

def load(seed,arm):
    ck=torch.load(ROOT/'checkpoints'/f'p1_{arm}_{seed}.pt',map_location='cpu',weights_only=True)
    assert ck['seed']==seed and ck['arm']==arm and ck['protocol_sha256']==PH
    net=DirectWorldModelP1().eval();net.load_state_dict(ck['model']);return net

def train(seed):
    assert not (ROOT/'results'/'P1_EXAM_UNLOCKED').exists()
    t0=time.time();tr=p0.make_dataset(seed,'train');dev=p0.make_dataset(seed,'dev')
    print('P1 DATA',seed,len(tr['node']),len(dev['node']),flush=True)
    result={'seed':seed,'protocol_sha256':PH,'arms':{}}
    for arm in P['arms']:
        torch.manual_seed(seed+102);net=DirectWorldModelP1()
        opt=torch.optim.AdamW(net.parameters(),lr=P['optimization']['lr'],weight_decay=P['optimization']['weight_decay'])
        rng=np.random.default_rng(seed+999)
        best=(float('inf'),float('inf'));snapshot=None;stepbest=None;hist=[]
        for step in range(1,P['optimization']['steps']+1):
            pi=rng.integers(0,p0.P['world_pairs_per_seed']['train'],size=P['optimization']['batch_pairs'])
            ix=torch.tensor(np.stack([2*pi,2*pi+1],-1).ravel())
            b=p0.subset(tr,ix)
            net.train();pr=net(b['node'],b['rel'],b['adj'],b['act'],b['support'],arm=='observed_context')
            query_loss=p0.loss_fn(pr,b)
            support_loss=net.withheld(b['support'],step%p0.K,arm=='observed_context')
            loss=query_loss+P['optimization']['support_loo_weight']*support_loss
            opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),P['optimization']['grad_clip']);opt.step()
            if step in P['optimization']['eval_steps']:
                met=p0.evaluate(net,dev,arm=='observed_context')
                hist.append({'step':step,**met})
                key=(met['loss'],met['node_mae']+met['relation_mae'])
                if key<best:best=key;snapshot=copy.deepcopy(net.state_dict());stepbest=step
        ck={'seed':seed,'arm':arm,'protocol_sha256':PH,'step':stepbest,'model':snapshot}
        torch.save(ck,ROOT/'checkpoints'/f'p1_{arm}_{seed}.pt')
        result['arms'][arm]={'selected_step':stepbest,'selected_dev':next(x for x in hist if x['step']==stepbest),'history':hist}
        print('P1 TRAIN',seed,arm,result['arms'][arm]['selected_dev'],'elapsed',round(time.time()-t0,1),flush=True)
    (ROOT/'results'/f'p1_train_{seed}.json').write_text(json.dumps(result,indent=2)+'\n')

@torch.no_grad()
def exam(seed):
    for s in P['seeds']:
        for arm in P['arms']:assert (ROOT/'checkpoints'/f'p1_{arm}_{s}.pt').exists()
    (ROOT/'results'/'P1_EXAM_UNLOCKED').write_text('All P1 checkpoints chosen by DEV before independent new-world EXAM.\n')
    d=p0.make_dataset(seed,'exam');ctrl=load(seed,'no_context');net=load(seed,'observed_context')
    out={'seed':seed,'protocol_sha256':PH,'n':len(d['node']),'metrics':{
      'no_context':p0.evaluate(ctrl,d,False),'observed_context':p0.evaluate(net,d,True)},'pairs':[]}
    pred=net(d['node'],d['rel'],d['adj'],d['act'],d['support'],True)
    swapped=d['support'].reshape(-1,2,p0.K,11).flip(1).reshape(-1,p0.K,11)
    swap=net(d['node'],d['rel'],d['adj'],d['act'],swapped,True)
    zeros=net(d['node'],d['rel'],d['adj'],d['act'],torch.zeros_like(d['support']),True)
    def err(q):
        return (q[0]-d['target_node']).abs().mean((1,2)) + (((q[1]-d['target_rel']).abs()*d['adj']).sum(1)/d['adj'].sum(1))
    e1,e2,e3=err(pred),err(swap),err(zeros)
    dist=torch.cat([(pred[0]-swap[0]).abs().reshape(len(e1),-1),(pred[1]-swap[1]).abs()],1).amax(1)
    truthdist=torch.cat([(d['target_node'][0::2]-d['target_node'][1::2]).abs().reshape(len(e1)//2,-1),
                        (d['target_rel'][0::2]-d['target_rel'][1::2]).abs()],1).amax(1)
    preddist=torch.cat([(pred[0][0::2]-pred[0][1::2]).abs().reshape(len(e1)//2,-1),
                        (pred[1][0::2]-pred[1][1::2]).abs()],1).amax(1)
    for j in range(len(e1)//2):
        k=2*j
        out['pairs'].append({'pair':j,'laws':d['law'][k:k+2],'graph':d['graph'][k],
            'true_err':[float(e1[k]),float(e1[k+1])],
            'swap_err':[float(e2[k]),float(e2[k+1])],
            'prediction_change':[float(dist[k]),float(dist[k+1])],
            'target_pair_difference':float(truthdist[j]),'predicted_pair_difference':float(preddist[j])})
    out['ablation']={'true_error':float(e1.mean()),'swapped_error':float(e2.mean()),'zero_error':float(e3.mean()),
         'prediction_changed_0.001':int((dist>0.001).sum()),'prediction_changed_0.01':int((dist>0.01).sum()),
         'swap_improves':int((e2<e1-1e-6).sum()),'swap_hurts':int((e2>e1+1e-6).sum()),
         'mean_target_pair_diff':float(truthdist.mean()),'mean_pred_pair_diff':float(preddist.mean()),'n':len(e1)}
    (ROOT/'results'/f'p1_exam_{seed}.json').write_text(json.dumps(out,indent=2)+'\n')
    print('P1 EXAM',seed,out['metrics'],out['ablation'],flush=True)

@torch.no_grad()
def rollout(seed):
    nets={a:load(seed,a) for a in P['arms']};records=[]
    for group,n in p0.P['rollout']['episodes_per_seed'].items():
        for j in range(n):
            rng=np.random.default_rng(55000000+seed*11393+j*1199+{'ood':0,'familiar':1000000,'scrambled':2000000}[group])
            gs=p0.P['graph_train'] if group=='familiar' else p0.P['graph_exam']
            ls=p0.TRAIN_LAWS if group=='familiar' else p0.EXAM_LAWS
            graph=gs[j%len(gs)];law=ls[j%len(ls)];adj=p0.graph_mask(graph)
            sn,sr=p0.random_state(rng,adj);obs=p0.make_context(rng,adj,[law])[law]
            goldn=sn.copy();goldr=sr.copy();states={a:(sn.copy(),sr.copy()) for a in nets}
            log={a:{'prefix_0.02':90,'prefix_0.05':90,'stop_at':None,'steps':[]} for a in nets}
            acts=[p0.random_action(rng,adj) for _ in range(90)]
            if group=='scrambled':acts=[acts[(i*37+11)%90] for i in range(90)]
            for i,act in enumerate(acts):
                goldn,goldr=p0.teacher_step(goldn,goldr,adj,act,law)
                for arm,net in nets.items():
                    z=log[arm]
                    if z['stop_at'] is not None:continue
                    nn,rr=states[arm]
                    def tt(v):return torch.from_numpy(np.asarray(v,dtype=np.float32))[None]
                    x=net(tt(nn),tt(rr),tt(adj),tt(act),tt(obs),arm=='observed_context')
                    newn,newr=x[0][0].numpy(),x[1][0].numpy()
                    invalid=bool((newn<0).any() or (newn>1).any() or
                        (newr[adj>0]<0).any() or (newr[adj>0]>1).any() or
                        not np.isfinite(newn).all() or not np.isfinite(newr).all())
                    err=float(max(np.abs(newn-goldn).max(),np.abs((newr-goldr)*adj).max()))
                    if err>.02 and z['prefix_0.02']==90:z['prefix_0.02']=i
                    if err>.05 and z['prefix_0.05']==90:z['prefix_0.05']=i
                    z['steps'].append({'step':i+1,'max_abs_error':err,'invalid':invalid})
                    if invalid:z['stop_at']=i+1
                    else:states[arm]=(newn,newr)
            for arm in nets:
                z=log[arm]
                for h in [1,4,16,90]:
                    z[f'H{h}_0.02']=int(z['prefix_0.02']>=h and (z['stop_at'] is None or z['stop_at']>h))
                    z[f'H{h}_0.05']=int(z['prefix_0.05']>=h and (z['stop_at'] is None or z['stop_at']>h))
            records.append({'seed':seed,'group':group,'graph':graph,'law_diagnostic':law,'models':log})
        print('P1 ROLLOUT',seed,group,n,flush=True)
    (ROOT/'results'/f'p1_rollout_{seed}.json').write_text(json.dumps({'seed':seed,'records':records},indent=2)+'\n')

def report():
    ex=[json.loads((ROOT/'results'/f'p1_exam_{s}.json').read_text()) for s in P['seeds']]
    ro=[r for s in P['seeds'] for r in json.loads((ROOT/'results'/f'p1_rollout_{s}.json').read_text())['records']]
    out={'project':'TWM ORION','stage':'F21-P1','protocol_sha256':PH,'exam':{},'ablation':{},'rollout':{}}
    for arm in P['arms']:
        out['exam'][arm]={k:sum(e['metrics'][arm][k] for e in ex)/len(ex) if k.endswith('mae') or k=='loss'
             else sum(e['metrics'][arm][k] for e in ex) for k in ex[0]['metrics'][arm]}
        out['rollout'][arm]={}
        for group in p0.P['rollout']['episodes_per_seed']:
            rs=[r['models'][arm] for r in ro if r['group']==group]
            out['rollout'][arm][group]={'n':len(rs),'halts':sum(r['stop_at'] is not None for r in rs),
               **{f'H{h}_0.02':sum(r[f'H{h}_0.02'] for r in rs) for h in [1,4,16,90]},
               **{f'H{h}_0.05':sum(r[f'H{h}_0.05'] for r in rs) for h in [1,4,16,90]}}
    out['ablation']={k:(sum(e['ablation'][k] for e in ex)/len(ex) if k in
            ['true_error','swapped_error','zero_error','mean_target_pair_diff','mean_pred_pair_diff']
            else sum(e['ablation'][k] for e in ex)) for k in ex[0]['ablation']}
    c,e=out['exam']['no_context'],out['exam']['observed_context']
    gate={'exam_node_mae_decrease':e['node_mae']<c['node_mae'],'exam_relation_mae_decrease':e['relation_mae']<c['relation_mae'],
        'swap_degrades':out['ablation']['swapped_error']>out['ablation']['true_error']*1.05,
        'ood_H16_improves':out['rollout']['observed_context']['ood']['H16_0.02']>out['rollout']['no_context']['ood']['H16_0.02'],
        'familiar_H4_no_regression':out['rollout']['observed_context']['familiar']['H4_0.02']>=out['rollout']['no_context']['familiar']['H4_0.02']}
    out['gate']=gate;out['status']='PASS' if all(gate.values()) else 'REJECT_NO_SYSTEM_GAIN'
    (ROOT/'results'/'P1_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
    print('P1 REPORT',out['status'],out['gate'],flush=True)

def tests():
    d=p0.make_dataset(1421,'train');b=p0.subset(d,torch.tensor([0,1]))
    net=DirectWorldModelP1().eval();sup=b['support']
    with torch.no_grad():
        a=net(b['node'],b['rel'],b['adj'],b['act'],sup)
        r=net(b['node'],b['rel'],b['adj'],b['act'],sup[:,torch.randperm(p0.K)])
        assert torch.allclose(a[0],r[0],atol=1e-6)
        assert net.withheld(sup,0,True)>=0
    assert 'teacher_step' not in DirectWorldModelP1.forward.__code__.co_names
    assert 'theta' not in DirectWorldModelP1.forward.__code__.co_names
    print('P1 TESTS PASSED: direct state, history permutation, observational LOO, no law handler',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('cmd',choices=['tests','train','exam','rollout','report']);ap.add_argument('--seed',type=int,default=1421);a=ap.parse_args()
    if a.cmd=='tests':tests()
    elif a.cmd=='train':train(a.seed)
    elif a.cmd=='exam':exam(a.seed)
    elif a.cmd=='rollout':rollout(a.seed)
    elif a.cmd=='report':report()
