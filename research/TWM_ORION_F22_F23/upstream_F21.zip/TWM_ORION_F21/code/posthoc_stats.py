#!/usr/bin/env python3
"""Posthoc paired bootstrap, NOT used for checkpoint choice or promotion."""
import json
from pathlib import Path
import numpy as np
import torch
import orion_f21 as p0
import orion_f21_p2 as p2
ROOT=Path(__file__).resolve().parents[1]
rows={k:[] for k in ('node_gain','relation_gain','near_gain','exact_gain','swap_cost')}
for seed in p2.P['seeds']:
    d=p2.make_data(seed,'exam');a=p2.load(seed,'no_context');b=p2.load(seed,'observed_context')
    with torch.no_grad():
        ca=a(d['node'],d['rel'],d['adj'],d['act'],d['support'],False)
        cb=b(d['node'],d['rel'],d['adj'],d['act'],d['support'],True)
    na=(ca[0]-d['target_node']).abs().mean((1,2)).numpy()
    nb=(cb[0]-d['target_node']).abs().mean((1,2)).numpy()
    ra=((ca[1]-d['target_rel']).abs()*d['adj']).sum(1).numpy()/d['adj'].sum(1).numpy()
    rb=((cb[1]-d['target_rel']).abs()*d['adj']).sum(1).numpy()/d['adj'].sum(1).numpy()
    def tol(pr):
        en=(pr[0]-d['target_node']).abs().amax((1,2)).numpy()
        er=((pr[1]-d['target_rel']).abs()*d['adj']).amax(1).numpy()
        return np.maximum(en,er)
    erra,errb=tol(ca),tol(cb)
    saved=json.loads((ROOT/'results'/f'p2_exam_{seed}.json').read_text())
    sq=np.array([np.mean(np.array(p['swapped_err'])-np.array(p['true_err'])) for p in saved['pairs']])
    diff={'node_gain':na-nb,'relation_gain':ra-rb,'near_gain':(errb<=.05).astype(float)-(erra<=.05).astype(float),
          'exact_gain':(errb<=.02).astype(float)-(erra<=.02).astype(float)}
    for key,val in diff.items():
        assert len(val)==320
        rows[key].append(val.reshape(-1,2).mean(1))
    rows['swap_cost'].append(sq)
rng=np.random.default_rng(20261104);out={'posthoc':True,'bootstrap_resamples':6000,'bootstrap_cluster':'world-pair, stratified by seed','metrics':{}}
for k,v in rows.items():
    vals=np.vstack(v) # seed x 160 pairs
    z=[]
    for _ in range(6000):
        ix=rng.integers(vals.shape[1],size=vals.shape)
        sample=np.take_along_axis(vals,ix,axis=1)
        z.append(float(sample.mean()))
    out['metrics'][k]={'mean':float(vals.mean()),'ci95':list(map(float,np.quantile(z,[.025,.975])))}
(ROOT/'results'/'P2_POSTHOC_STATS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
