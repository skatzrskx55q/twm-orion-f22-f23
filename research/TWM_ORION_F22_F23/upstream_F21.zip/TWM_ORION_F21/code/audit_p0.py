#!/usr/bin/env python3
"""Posthoc analysis; no training or new checkpoint selection."""
import json,sys
from pathlib import Path
import torch
import orion_f21 as m
root=Path(__file__).resolve().parents[1]
out={'posthoc':True,'note':'EXAM opened before this diagnostic; no tuning F21-P0 weights','rows':[]}
for seed in m.P['seeds']:
  a=m.load(seed,'no_context');b=m.load(seed,'observed_context')
  for split in ('train','dev','exam'):
    d=m.make_dataset(seed,split)
    with torch.no_grad():
      am=m.evaluate(a,d,False);bm=m.evaluate(b,d,True)
      p=b(d['node'],d['rel'],d['adj'],d['act'],d['support'],True)
      s=d['support'].reshape(-1,2,m.K,11).flip(1).reshape(-1,m.K,11)
      ps=b(d['node'],d['rel'],d['adj'],d['act'],s,True)
      z=b.memory(d['support']).mean(1)
      dz=(z[0::2]-z[1::2]).norm(dim=-1)
      pred=torch.cat([(p[0][0::2]-p[0][1::2]).abs().reshape(len(dz),-1),
                      (p[1][0::2]-p[1][1::2]).abs()],dim=1).amax(1)
      true=torch.cat([(d['target_node'][0::2]-d['target_node'][1::2]).abs().reshape(len(dz),-1),
                      (d['target_rel'][0::2]-d['target_rel'][1::2]).abs()],dim=1).amax(1)
      swapchange=torch.cat([(p[0]-ps[0]).abs().reshape(len(z),-1),(p[1]-ps[1]).abs()],1).amax(1)
      out['rows'].append({'seed':seed,'split':split,'no_context_mae_node':am['node_mae'],
        'observed_mae_node':bm['node_mae'],'mean_memory_distance':float(dz.mean()),
        'mean_predicted_pair_difference':float(pred.mean()),'mean_target_pair_difference':float(true.mean()),
        'mean_swap_prediction_change':float(swapchange.mean()),'fraction_pair_preds_below_1e-3':float((pred<0.001).float().mean())})
(root/'results'/'P0_POSTHOC_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
