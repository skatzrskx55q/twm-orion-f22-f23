#!/usr/bin/env python3
"""POSTHOC audit of rollout model violations and teacher boundary/clipping, not inference."""
import json
import numpy as np
from pathlib import Path
import orion_f21 as p0
import orion_f21_p1 as p1
ROOT=Path(__file__).resolve().parents[1]

def raw_teacher(node,rel,adj,act,law):
    th=p0.theta(law);du=node[p0.EI,0]-node[p0.EJ,0];dp=node[p0.EI,1]-node[p0.EJ,1];rd=rel-.5
    fr=.085*act*np.tanh(th[0]*du+th[1]*dp+th[2]*rd)
    fp=.055*act*np.tanh(th[1]*du-th[0]*dp+th[2]*rd)
    drel=.04*act*np.tanh(th[2]*du+th[0]*dp+th[1]*rd)
    nn=node+np.stack([np.einsum('en,e->n',p0.INC,fr),np.einsum('en,e->n',p0.INC,fp)],-1)
    rr=rel+drel
    return nn,rr

def audit():
    metrics={'p0':{},'p1':{}}
    for stage,seeds in [('p0',p0.P['seeds']),('p1',p1.P['seeds'])]:
        rec=[r for seed in seeds for r in json.loads((ROOT/'results'/
           (f'p1_rollout_{seed}.json' if stage=='p1' else f'rollout_{seed}.json')).read_text())['records']]
        for arm in p0.P['arms']:
            rows=[r['models'][arm] for r in rec]
            stop=[r['stop_at'] for r in rows if r['stop_at'] is not None]
            first05=[next((x['step'] for x in r['steps'] if x['max_abs_error']>.05),None) for r in rows]
            metrics[stage][arm]={'n':len(rows),'halted':len(stop),'mean_stop_at':float(np.mean(stop)) if stop else None,
             'median_stop_at':float(np.median(stop)) if stop else None,
             'mean_steps_observed':float(np.mean([len(r['steps']) for r in rows])),
             'first_above_0.05':first05,
             'first_step_max_abs_error_mean':float(np.mean([r['steps'][0]['max_abs_error'] for r in rows]))}
    clipping={}
    for stage,seeds in [('p0',p0.P['seeds']),('p1',p1.P['seeds'])]:
        nsteps=0;clipcnt=0;first=[];losscon=[]
        for seed in seeds:
            for group,n in p0.P['rollout']['episodes_per_seed'].items():
                for j in range(n):
                    start=(44000000 if stage=='p0' else 55000000)
                    rng=np.random.default_rng(start+seed*11393+j*1199+{'ood':0,'familiar':1000000,'scrambled':2000000}[group])
                    gs=p0.P['graph_train'] if group=='familiar' else p0.P['graph_exam']
                    ls=p0.TRAIN_LAWS if group=='familiar' else p0.EXAM_LAWS
                    graph=gs[j%len(gs)];law=ls[j%len(ls)];adj=p0.graph_mask(graph)
                    st,rel=p0.random_state(rng,adj)
                    _=p0.make_context(rng,adj,[law])
                    acts=[p0.random_action(rng,adj) for _ in range(90)]
                    if group=='scrambled':acts=[acts[(t*37+11)%90] for t in range(90)]
                    fc=None
                    for i,a in enumerate(acts):
                        rawr,rawrel=raw_teacher(st,rel,adj,a,law)
                        newr,newrel=p0.teacher_step(st,rel,adj,a,law)
                        clipped=bool(np.max(np.abs(newr-rawr))>1e-6 or np.max(np.abs((newrel-rawrel)*adj))>1e-6)
                        nsteps+=1;clipcnt+=int(clipped)
                        if clipped and fc is None:fc=i+1
                        # Deviations from conservation arise when teacher clips.
                        losscon.append(float(abs(newr.sum(0)[0]-st.sum(0)[0])))
                        st,rel=newr,newrel
                    first.append(fc)
        clipping[stage]={'teacher_total_steps':nsteps,'steps_with_teacher_clipping':clipcnt,
           'episodes_teacher_clipped':sum(x is not None for x in first),'first_clip_step':first,
           'mean_abs_resource_conservation_error_per_step':float(np.mean(losscon))}
    out={'posthoc':True,'note':'All rollouts on a NEW synthetic world, not historic NC3','models':metrics,'teacher':clipping}
    (ROOT/'results'/'ROLL_OUT_DIAGNOSTIC.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':audit()
