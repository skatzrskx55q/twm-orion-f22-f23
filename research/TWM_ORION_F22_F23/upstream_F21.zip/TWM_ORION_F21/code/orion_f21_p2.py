#!/usr/bin/env python3
"""TWM ORION F21-P2. Non-conservative learned node updates with bounded state coordinates.
The bound is representation (not teacher label/repair). Historic checkpoints untouched.
"""
from __future__ import annotations
import argparse,copy,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
from torch import nn
import orion_f21 as p0
import orion_f21_p1 as p1
ROOT=Path(__file__).resolve().parents[1]
PF=ROOT/'configs/PROTOCOL_P2_FROZEN.json';P=json.loads(PF.read_text());PH=hashlib.sha256(PF.read_bytes()).hexdigest()
assert PH==(ROOT/'configs/PROTOCOL_P2_SHA256.txt').read_text().strip()
torch.set_num_threads(1)

class DirectWorldModelP2(p1.DirectWorldModelP1):
    """Learn state transitions, node residuals and relation transitions from causal memory.

    Bound is encoded in coordinates: x' = x + positive*(1-x) + negative*x,
    where signed fraction is learned and tanh-bounded. It does not encode
    any causal rule, teacher mask, transition label or oracle correction.
    """
    def __init__(self):
        super().__init__()
        self.node_fix=nn.Sequential(nn.Linear(38,64),nn.SiLU(),nn.Linear(64,64),nn.SiLU(),nn.Linear(64,2))
        nn.init.zeros_(self.node_fix[-1].weight);nn.init.zeros_(self.node_fix[-1].bias)
    @staticmethod
    def bounded(current,delta):
        u=torch.tanh(delta)
        return current+torch.relu(u)*(1-current)-torch.relu(-u)*current
    def forward(self,node,rel,adj,act,support,use_context=True):
        B=node.shape[0];z=self.latent(support,use_context)
        edge_input=torch.cat([node[:,self.ei],node[:,self.ej],rel[...,None],
                              act[...,None],adj[...,None],z[:,None,:].expand(B,p0.E,32)],-1)
        flows=self.flow(edge_input)*act[...,None]*adj[...,None]
        routed=torch.einsum('en,bec->bnc',self.inc,flows[...,:2])
        counts=torch.einsum('en,be->bn',self.inc.abs(),act)
        relavg=torch.einsum('en,be->bn',self.inc.abs(),rel*adj)/self.inc.abs().sum(0).clamp_min(1)[None]
        local_input=torch.cat([node,routed,counts[...,None],relavg[...,None],z[:,None,:].expand(B,p0.N,32)],-1)
        correction=self.node_fix(local_input) * counts[...,None].clamp(0,2)
        node_after=self.bounded(node,routed+correction)
        rel_after=self.bounded(rel,flows[...,2])
        return node_after,rel_after,node_after-node,rel_after-rel


def make_data(seed,split):
    cfg=P['data'];rng=np.random.default_rng({'train':66000000,'dev':77000000,'exam':88000000}[split]+seed*3137)
    graphs=P['train_graphs'] if split in ('train','dev') else P['exam_graphs']
    laws={'train':p0.TRAIN_LAWS,'dev':p0.DEV_LAWS,'exam':p0.EXAM_LAWS}[split]
    count=cfg[f'{split}_pairs'];obj={key:[] for key in ['node','rel','adj','act','support','target_node','target_rel','law','pair_id','graph','pre_roll_steps']}
    for j in range(count):
        graph=graphs[j%len(graphs)];adj=p0.graph_mask(graph);node,rel=p0.random_state(rng,adj)
        steps=int(rng.choice(cfg['teacher_pre_rollout_steps']));ref_law=str(rng.choice(p0.TRAIN_LAWS))
        for _ in range(steps):
            act=p0.random_action(rng,adj);node,rel=p0.teacher_step(node,rel,adj,act,ref_law)
        action=p0.random_action(rng,adj)
        l1,l2=rng.choice(laws,size=2,replace=False)
        support=p0.make_context(rng,adj,[l1,l2])
        for law in (l1,l2):
            nn,rr=p0.teacher_step(node,rel,adj,action,law)
            for name,val in [('node',node),('rel',rel),('adj',adj),('act',action),('support',support[law]),
                ('target_node',nn),('target_rel',rr),('law',str(law)),('pair_id',j),('graph',graph),('pre_roll_steps',steps)]:obj[name].append(val)
    out={key:torch.from_numpy(np.stack(obj[key])).float() for key in ('node','rel','adj','act','support','target_node','target_rel')}
    out.update({k:obj[k] for k in ('law','pair_id','graph','pre_roll_steps')})
    out['stats']={'boundary_query_node_fraction':float(((out['node']<=.03)|(out['node']>=.97)).float().mean()),
       'boundary_target_node_fraction':float(((out['target_node']<=.03)|(out['target_node']>=.97)).float().mean()),
       'zero_prior_steps_fraction':float(np.mean(np.array(obj['pre_roll_steps'])==0))}
    return out

def load(seed,arm):
    ck=torch.load(ROOT/'checkpoints'/f'p2_{arm}_{seed}.pt',weights_only=True,map_location='cpu')
    assert ck['seed']==seed and ck['arm']==arm and ck['protocol_sha256']==PH
    net=DirectWorldModelP2().eval();net.load_state_dict(ck['model']);return net

def train(seed):
    assert not (ROOT/'results'/'P2_EXAM_UNLOCKED').exists()
    t=time.time();tr=make_data(seed,'train');dev=make_data(seed,'dev')
    print('P2 DATA',seed,tr['stats'],dev['stats'],flush=True)
    out={'seed':seed,'protocol_sha256':PH,'train_stats':tr['stats'],'dev_stats':dev['stats'],'arms':{}}
    for arm in P['arms']:
        torch.manual_seed(seed+102);net=DirectWorldModelP2()
        opt=torch.optim.AdamW(net.parameters(),lr=P['optimization']['lr'],weight_decay=P['optimization']['weight_decay'])
        rng=np.random.default_rng(seed+999)
        best=(float('inf'),float('inf'));snapshot=None;stepbest=None;hist=[]
        for step in range(1,P['optimization']['steps']+1):
            pi=rng.integers(0,P['data']['train_pairs'],size=P['optimization']['batch_pairs'])
            ix=torch.tensor(np.stack([2*pi,2*pi+1],-1).ravel());b=p0.subset(tr,ix)
            pred=net(b['node'],b['rel'],b['adj'],b['act'],b['support'],arm=='observed_context')
            qloss=p0.loss_fn(pred,b);sloss=net.withheld(b['support'],step%p0.K,arm=='observed_context')
            loss=qloss+P['optimization']['support_loo_weight']*sloss
            opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(net.parameters(),P['optimization']['grad_clip']);opt.step()
            if step in P['optimization']['eval_steps']:
                met=p0.evaluate(net,dev,arm=='observed_context');hist.append({'step':step,**met})
                key=(met['loss'],met['node_mae']+met['relation_mae'])
                if key<best:best=key;snapshot=copy.deepcopy(net.state_dict());stepbest=step
        ck={'seed':seed,'arm':arm,'protocol_sha256':PH,'step':stepbest,'model':snapshot}
        torch.save(ck,ROOT/'checkpoints'/f'p2_{arm}_{seed}.pt')
        out['arms'][arm]={'selected_step':stepbest,'selected_dev':next(x for x in hist if x['step']==stepbest),'history':hist}
        print('P2 TRAIN',seed,arm,out['arms'][arm]['selected_dev'],'elapsed',round(time.time()-t,1),flush=True)
    (ROOT/'results'/f'p2_train_{seed}.json').write_text(json.dumps(out,indent=2)+'\n')

@torch.no_grad()
def exam(seed):
    for s in P['seeds']:
        for a in P['arms']:assert (ROOT/'checkpoints'/f'p2_{a}_{s}.pt').exists()
    (ROOT/'results'/'P2_EXAM_UNLOCKED').write_text('All P2 weights chosen on DEV before new EXAM.\n')
    d=make_data(seed,'exam');ctrl=load(seed,'no_context');net=load(seed,'observed_context')
    out={'seed':seed,'protocol_sha256':PH,'n':len(d['node']),'stats':d['stats'],'metrics':{
        'no_context':p0.evaluate(ctrl,d,False),'observed_context':p0.evaluate(net,d,True)},'pairs':[]}
    pred=net(d['node'],d['rel'],d['adj'],d['act'],d['support'],True)
    swapped=d['support'].reshape(-1,2,p0.K,11).flip(1).reshape(-1,p0.K,11)
    swap=net(d['node'],d['rel'],d['adj'],d['act'],swapped,True)
    zero=net(d['node'],d['rel'],d['adj'],d['act'],torch.zeros_like(d['support']),True)
    def err(pr):return (pr[0]-d['target_node']).abs().mean((1,2)) + (((pr[1]-d['target_rel']).abs()*d['adj']).sum(1)/d['adj'].sum(1))
    e1,e2,e3=err(pred),err(swap),err(zero)
    change=torch.cat([(pred[0]-swap[0]).abs().reshape(len(e1),-1),(pred[1]-swap[1]).abs()],1).amax(1)
    truepair=torch.cat([(d['target_node'][0::2]-d['target_node'][1::2]).abs().reshape(-1,p0.N*2),
                        (d['target_rel'][0::2]-d['target_rel'][1::2]).abs()],1).amax(1)
    predictedpair=torch.cat([(pred[0][0::2]-pred[0][1::2]).abs().reshape(-1,p0.N*2),
                             (pred[1][0::2]-pred[1][1::2]).abs()],1).amax(1)
    for j in range(len(e1)//2):
        k=2*j
        out['pairs'].append({'pair':j,'laws':d['law'][k:k+2],'graph':d['graph'][k],
            'pre_roll_steps':d['pre_roll_steps'][k],'true_err':[float(e1[k]),float(e1[k+1])],
            'swapped_err':[float(e2[k]),float(e2[k+1])], 'prediction_change':[float(change[k]),float(change[k+1])],
            'target_pair_difference':float(truepair[j]),'predicted_pair_difference':float(predictedpair[j])})
    out['ablation']={'true_error':float(e1.mean()),'swapped_error':float(e2.mean()),'zero_error':float(e3.mean()),
        'changed_0.001':int((change>.001).sum()),'changed_0.01':int((change>.01).sum()),
        'swap_improves':int((e2<e1-1e-6).sum()),'swap_hurts':int((e2>e1+1e-6).sum()),
        'mean_true_pair_difference':float(truepair.mean()),'mean_pred_pair_difference':float(predictedpair.mean()),'n':len(e1)}
    (ROOT/'results'/f'p2_exam_{seed}.json').write_text(json.dumps(out,indent=2)+'\n')
    print('P2 EXAM',seed,out['metrics'],out['ablation'],flush=True)

@torch.no_grad()
def rollout(seed):
    models={a:load(seed,a) for a in P['arms']};records=[]
    for group,count in P['rollout']['episodes_per_seed'].items():
        for j in range(count):
            rng=np.random.default_rng(99000000+seed*11393+j*1199+{'ood':0,'familiar':1000000,'scrambled':2000000}[group])
            graphs=P['train_graphs'] if group=='familiar' else P['exam_graphs']
            laws=p0.TRAIN_LAWS if group=='familiar' else p0.EXAM_LAWS
            graph=graphs[j%len(graphs)];law=laws[j%len(laws)]
            adj=p0.graph_mask(graph);node,rel=p0.random_state(rng,adj)
            support=p0.make_context(rng,adj,[law])[law]
            gold_node,gold_rel=node.copy(),rel.copy();states={a:(node.copy(),rel.copy()) for a in models}
            logs={a:{'prefix_0.02':90,'prefix_0.05':90,'stop_at':None,'steps':[]} for a in models}
            acts=[p0.random_action(rng,adj) for _ in range(90)]
            if group=='scrambled':acts=[acts[(i*37+11)%90] for i in range(90)]
            for t,act in enumerate(acts):
                gold_node,gold_rel=p0.teacher_step(gold_node,gold_rel,adj,act,law)
                for arm,net in models.items():
                    z=logs[arm]
                    if z['stop_at'] is not None:continue
                    sn,sr=states[arm]
                    def tt(v):return torch.as_tensor(np.asarray(v,dtype=np.float32))[None]
                    q=net(tt(sn),tt(sr),tt(adj),tt(act),tt(support),arm=='observed_context')
                    pn,pr=q[0][0].numpy(),q[1][0].numpy()
                    invalid=bool((pn<-1e-6).any() or (pn>1+1e-6).any() or
                        (pr[adj>0]<-1e-6).any() or (pr[adj>0]>1+1e-6).any() or
                        not np.isfinite(pn).all() or not np.isfinite(pr).all())
                    er=float(max(np.abs(pn-gold_node).max(),np.abs((pr-gold_rel)*adj).max()))
                    if er>.02 and z['prefix_0.02']==90:z['prefix_0.02']=t
                    if er>.05 and z['prefix_0.05']==90:z['prefix_0.05']=t
                    z['steps'].append({'step':t+1,'max_abs_error':er,'invalid':invalid})
                    if invalid:z['stop_at']=t+1
                    else:states[arm]=(pn,pr)
            for arm in models:
                z=logs[arm]
                for h in [1,4,16,90]:
                    z[f'H{h}_0.02']=int(z['prefix_0.02']>=h and (z['stop_at'] is None or z['stop_at']>h))
                    z[f'H{h}_0.05']=int(z['prefix_0.05']>=h and (z['stop_at'] is None or z['stop_at']>h))
            records.append({'seed':seed,'group':group,'graph':graph,'law_diagnostic':law,'models':logs})
        print('P2 ROLLOUT',seed,group,count,flush=True)
    (ROOT/'results'/f'p2_rollout_{seed}.json').write_text(json.dumps({'seed':seed,'records':records},indent=2)+'\n')

def report():
    exam=[json.loads((ROOT/'results'/f'p2_exam_{s}.json').read_text()) for s in P['seeds']]
    ro=[r for seed in P['seeds'] for r in json.loads((ROOT/'results'/f'p2_rollout_{seed}.json').read_text())['records']]
    out={'project':'TWM ORION','stage':'F21-P2','protocol_sha256':PH,'exam':{},'rollout':{},'ablation':{}}
    for arm in P['arms']:
        out['exam'][arm]={k:(sum(e['metrics'][arm][k] for e in exam)/len(exam) if k in
             ['node_mae','relation_mae','loss'] else sum(e['metrics'][arm][k] for e in exam))
             for k in exam[0]['metrics'][arm]}
        out['rollout'][arm]={}
        for group in P['rollout']['episodes_per_seed']:
            rs=[r['models'][arm] for r in ro if r['group']==group]
            out['rollout'][arm][group]={'n':len(rs),'halts':sum(r['stop_at'] is not None for r in rs),
                **{f'H{h}_0.02':sum(r[f'H{h}_0.02'] for r in rs) for h in [1,4,16,90]},
                **{f'H{h}_0.05':sum(r[f'H{h}_0.05'] for r in rs) for h in [1,4,16,90]}}
    out['ablation']={k:(sum(e['ablation'][k] for e in exam)/len(exam) if k in
        ['true_error','swapped_error','zero_error','mean_true_pair_difference','mean_pred_pair_difference']
        else sum(e['ablation'][k] for e in exam)) for k in exam[0]['ablation']}
    a,b=out['exam']['no_context'],out['exam']['observed_context']
    gate={'node_mae_improved':b['node_mae']<a['node_mae'],'relation_mae_improved':b['relation_mae']<a['relation_mae'],
      'swap_degrades':out['ablation']['swapped_error']>out['ablation']['true_error'],
      'ood_H4_0.05_improves':out['rollout']['observed_context']['ood']['H4_0.05']>out['rollout']['no_context']['ood']['H4_0.05'],
      'familiar_H4_0.05_no_regression':out['rollout']['observed_context']['familiar']['H4_0.05']>=out['rollout']['no_context']['familiar']['H4_0.05']}
    out['gate']=gate;out['status']='PASS' if all(gate.values()) else 'REJECT_NO_SYSTEM_GAIN'
    (ROOT/'results'/'P2_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n')
    print('P2 REPORT',out['status'],out['gate'],flush=True)

def tests():
    d=make_data(1521,'train');assert len(d['node'])==960
    assert d['stats']['boundary_query_node_fraction']>.01
    for k in ('node','rel','adj','act'):assert torch.equal(d[k][0::2],d[k][1::2])
    b=p0.subset(d,torch.tensor([0,1]));net=DirectWorldModelP2().eval()
    with torch.no_grad():
        y=net(b['node'],b['rel'],b['adj'],b['act'],b['support'])
        assert torch.all(y[0]>=0) and torch.all(y[0]<=1)
        assert torch.all(y[1][b['adj']>0]>=0) and torch.all(y[1][b['adj']>0]<=1)
        q=net(b['node'],b['rel'],b['adj'],b['act'],b['support'][:,torch.randperm(p0.K)])
        assert torch.allclose(y[0],q[0],atol=1e-6)
    assert not set(DirectWorldModelP2.forward.__code__.co_names)&{'teacher_step','theta','offline_label'}
    print('P2 TESTS PASSED: boundary-rich paired worlds, bounded coordinates, history permutation, no teacher forward',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('cmd',choices=['tests','train','exam','rollout','report']);ap.add_argument('--seed',type=int,default=1521);a=ap.parse_args()
    if a.cmd=='tests':tests()
    elif a.cmd=='train':train(a.seed)
    elif a.cmd=='exam':exam(a.seed)
    elif a.cmd=='rollout':rollout(a.seed)
    elif a.cmd=='report':report()
