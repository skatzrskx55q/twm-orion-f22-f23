#!/usr/bin/env python3
"""Verify internal hashes, protocol SHA and checkpoint provenance from extracted stage.
No models trained, no archived files modified.
"""
from pathlib import Path
import hashlib,json,zipfile
import torch
R=Path(__file__).resolve().parents[1]
lines=(R/'MANIFEST_SHA256.txt').read_text().splitlines()
checked=0
for line in lines:
    if not line.strip():continue
    digest,path=line.split('  ',1)
    dest=R/path
    if not dest.is_file():raise AssertionError(f'Missing {path}')
    if hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:raise AssertionError(f'Hash mismatch {path}')
    checked+=1
for stem in ('','_P1','_P2'):
    f=R/'configs'/('PROTOCOL'+stem+'_FROZEN.json')
    if stem=='':f=R/'configs/PROTOCOL_FROZEN.json'
    s=R/'configs'/('PROTOCOL'+stem+'_SHA256.txt' if stem else 'PROTOCOL_SHA256.txt')
    assert hashlib.sha256(f.read_bytes()).hexdigest()==s.read_text().strip()
for stage,seeds,prefix,marks in [('P0',[1321,1323],'',""),('P1',[1421,1423],'p1_','P1'),('P2',[1521,1523],'p2_','P2')]:
    for seed in seeds:
        for arm in ('no_context','observed_context'):
            path=R/'checkpoints'/f'{prefix}{arm}_{seed}.pt'
            item=torch.load(path,weights_only=True,map_location='cpu')
            assert item['seed']==seed and item['arm']==arm and 'model' in item
with zipfile.ZipFile(R/'upstream_F20.zip') as z:
    assert z.testzip() is None and 'TWM_ORION_F20/README_START_HERE_RU.md' in z.namelist()
print(f'QA PASS: {checked} SHA256 files, 3 protocol hashes, 12 checkpoint headers, parent ZIP integrity')
